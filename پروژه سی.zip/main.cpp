
#include <bits/stdc++.h>
#include "mini_json.hpp"

using namespace std;
using minijson::Value;

// -------------------- Utilities --------------------
static string read_file(const string& path) {
    ifstream in(path);
    if (!in) throw runtime_error("Cannot open file: " + path);
    std::ostringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

static string kw_to_string(uint32_t kw) {
    vector<string> parts;
    if (kw & (1u<<0)) parts.push_back("Taunt");
    if (kw & (1u<<1)) parts.push_back("DivineShield");
    if (kw & (1u<<2)) parts.push_back("Reborn");
    if (kw & (1u<<3)) parts.push_back("Windfury");
    if (parts.empty()) return "";
    string out;
    for (size_t i=0;i<parts.size();i++){
        if (i) out += ",";
        out += parts[i];
    }
    return out;
}

static uint32_t parse_keywords(const Value& v) {
    // keywords may be array of strings, or bitmask number, or missing
    if (v.is_number()) return (uint32_t)v.as_i64(0);
    if (!v.is_array()) return 0;
    uint32_t mask = 0;
    for (auto &x : v.a) {
        string s = x.as_string();
        for (auto &c: s) c = (char)tolower(c);
        if (s=="taunt") mask |= (1u<<0);
        else if (s=="divine_shield"||s=="divineshield"||s=="divine shield") mask |= (1u<<1);
        else if (s=="reborn") mask |= (1u<<2);
        else if (s=="windfury") mask |= (1u<<3);
    }
    return mask;
}

// -------------------- Deterministic RNG (PCG64 minimal) --------------------
struct PCG64 {
    using u128 = unsigned __int128;
    uint64_t inc;
    u128 state;

    PCG64(uint64_t seed = 0xDEADBEEFCAFEBABEull, uint64_t stream = 54u) { seed_rng(seed, stream); }

    void seed_rng(uint64_t seed, uint64_t stream) {
        inc = (stream<<1u) | 1u;
        state = 0;
        next_u64();
        state += (u128)seed;
        next_u64();
    }

    uint64_t next_u64() {
        u128 old = state;
        state = old * (u128)6364136223846793005ULL + (u128)inc;
        uint64_t xorshifted = (uint64_t)(((old >> 64u) ^ old) >> 64u);
        uint64_t rot = (uint64_t)(old >> 122u);
        return (xorshifted >> rot) | (xorshifted << ((-rot) & 63));
    }

    int next_int(int n) {
        if (n<=0) return 0;
        uint64_t bound = (uint64_t)n;
        uint64_t threshold = (uint64_t)(-bound) % bound;
        while (true) {
            uint64_t r = next_u64();
            if (r >= threshold) return (int)(r % bound);
        }
    }
};

// -------------------- Model --------------------
static constexpr int BOARD_SIZE = 7;
static constexpr int HAND_SIZE = 10;
enum KeywordBits : uint32_t {
    TAUNT = 1u<<0,
    DIVINE_SHIELD = 1u<<1,
    REBORN = 1u<<2,
    WINDFURY = 1u<<3
};

struct Minion {
    string card_id;
    string instance_id;
    int attack=0, health=0, max_health=0;
    uint32_t keywords=0;
    bool golden=false;

    bool alive() const { return health > 0; }
};

struct PlayerState {
    string player_id="p1";
    string hero_id;
    int health=40;
    int tavern_tier=1;
    int gold=3;
    bool shop_frozen=false;

    array<optional<Minion>, BOARD_SIZE> board;
    vector<Minion> hand;
    vector<optional<Minion>> shop; // size depends on tavern tier in full game; we keep variable
};

struct LeaderEntry {
    string player_id;
    int health=40;
    int tavern_tier=1;
    bool is_dead=false;
};

struct GameState {
    unordered_map<string, PlayerState> players;
    vector<LeaderEntry> leaderboard;
    int turn=1;
    uint64_t seed_combat=1;
};

// -------------------- Card DB (minimal subset used by combat/recruit demo) --------------------
struct SummonSpec {
    string card_id;
    int attack, health;
    uint32_t keywords=0;
};
struct CardDef {
    string card_id;
    int base_attack=0;
    int base_health=0;
    uint32_t base_keywords=0;
    bool is_demon=false;
    bool is_macaw=false;
    vector<SummonSpec> deathrattle_summons; // triggered on death
};

static CardDef carddef(const string& id) {
    // Tokens
    if (id=="BG_TOKEN_BEETLE_11") return CardDef{id,1,1,0,false,false,{}};
    if (id=="ImpToken") return CardDef{id,3,3,TAUNT,true,false,{}};

    // Beetle build set
    if (id=="BuzzingVermin") {
        CardDef d{id,2,2,TAUNT,false,false,{{"BG_TOKEN_BEETLE_11",1,1,0}}};
        return d;
    }
    if (id=="NestSwarmer") {
        CardDef d{id,2,3,0,false,false,{
            {"BG_TOKEN_BEETLE_11",1,1,0},{"BG_TOKEN_BEETLE_11",1,1,0},{"BG_TOKEN_BEETLE_11",1,1,0}
        }};
        return d;
    }
    if (id=="MonstrousMacaw") {
        CardDef d{id,3,2,0,false,true,{}};
        return d;
    }

    // Demon loop set (simplified behaviors)
    if (id=="WrathWeaver") { // Simplified: no hero damage; when you PLAY a demon -> +2/+2
        CardDef d{id,1,4,0,false,false,{}};
        return d;
    }
    if (id=="FuriousDriver") { // Simplified: Battlecry consumes 1 shop demon -> gains its stats
        CardDef d{id,3,3,0,false,false,{}};
        return d;
    }
    if (id=="Implicator") { // End of turn: consume 1 shop minion -> gains stats (simplified)
        CardDef d{id,1,6,0,true,false,{}};
        return d;
    }
    if (id=="Felbat") { // End of turn: all demons consume (not implemented)
        CardDef d{id,4,5,0,true,false,{}};
        return d;
    }
    if (id=="ImpMama") {
        CardDef d{id,6,8,TAUNT,true,false,{{"ImpToken",3,3,TAUNT}}};
        return d;
    }

    // Vanilla fallback
    return CardDef{id,2,2,0,false,false,{}};
}

static Minion make_minion(const string& card_id, const string& inst_id="") {
    CardDef d = carddef(card_id);
    Minion m;
    m.card_id = card_id;
    m.instance_id = inst_id;
    m.attack = d.base_attack;
    m.health = d.base_health;
    m.max_health = d.base_health;
    m.keywords = d.base_keywords;
    m.golden = false;
    return m;
}

// -------------------- Rendering (CLI) --------------------
static void print_minion(const optional<Minion>& om) {
    if (!om) { cout << "[   empty   ]"; return; }
    const auto& m = *om;
    cout << "[" << setw(2) << m.attack << "/" << setw(2) << m.health << " " << m.card_id;
    string kw = kw_to_string(m.keywords);
    if (!kw.empty()) cout << " {" << kw << "}";
    cout << "]";
}

static void show_player(const PlayerState& p) {
    cout << "Player " << p.player_id
         << "  HP=" << p.health
         << "  Tier=" << p.tavern_tier
         << "  Gold=" << p.gold
         << "  Frozen=" << (p.shop_frozen?"yes":"no")
         << "\n";

    cout << "Board:\n";
    for (int i=0;i<BOARD_SIZE;i++){
        cout << "  " << i << ": ";
        print_minion(p.board[i]);
        cout << "\n";
    }

    cout << "Hand:\n";
    for (size_t i=0;i<p.hand.size();i++){
        cout << "  " << i << ": [" << p.hand[i].attack << "/" << p.hand[i].health << " " << p.hand[i].card_id << "]\n";
    }
    if (p.hand.empty()) cout << "  (empty)\n";

    cout << "Shop:\n";
    for (size_t i=0;i<p.shop.size();i++){
        cout << "  " << i << ": ";
        if (p.shop[i]) {
            cout << "[" << p.shop[i]->attack << "/" << p.shop[i]->health << " " << p.shop[i]->card_id << "]";
        } else {
            cout << "[   empty   ]";
        }
        cout << "\n";
    }
    if (p.shop.empty()) cout << "  (empty)\n";
}

static void show_leaderboard(const GameState& st) {
    if (st.leaderboard.empty()) return;
    cout << "\nLeaderboard:\n";
    cout << "  player_id   hp   tier  dead\n";
    for (auto &e: st.leaderboard) {
        cout << "  " << setw(8) << e.player_id
             << "  " << setw(3) << e.health
             << "   " << setw(2) << e.tavern_tier
             << "   " << (e.is_dead?"yes":"no") << "\n";
    }
    cout << "\n";
}

// -------------------- Combat Engine (matches described loop: leftmost attacker, taunt targeting, simultaneous dmg, death queue) --------------------
struct DeathItem {
    int side=0; // 0 A, 1 B
    int slot=-1;
    Minion snap;
};

struct BoardRef {
    array<optional<Minion>, BOARD_SIZE>* board=nullptr;
};

static int alive_count(const array<optional<Minion>, BOARD_SIZE>& b) {
    int c=0; for (auto &s: b) if (s && s->health>0) c++; return c;
}
static int leftmost_alive(const array<optional<Minion>, BOARD_SIZE>& b) {
    for (int i=0;i<BOARD_SIZE;i++) if (b[i] && b[i]->health>0) return i;
    return -1;
}
static vector<int> alive_indices(const array<optional<Minion>, BOARD_SIZE>& b) {
    vector<int> v;
    for (int i=0;i<BOARD_SIZE;i++) if (b[i] && b[i]->health>0) v.push_back(i);
    return v;
}
static bool board_full(const array<optional<Minion>, BOARD_SIZE>& b) {
    for (auto &s: b) if (!s) return false;
    return true;
}
static int first_empty(const array<optional<Minion>, BOARD_SIZE>& b) {
    for (int i=0;i<BOARD_SIZE;i++) if (!b[i]) return i;
    return -1;
}

static void apply_hit(Minion& def, int dmg) {
    if (dmg<=0) return;
    if (def.keywords & DIVINE_SHIELD) {
        def.keywords &= ~DIVINE_SHIELD;
        return;
    }
    def.health -= dmg;
}

static vector<int> pick_targets(const array<optional<Minion>, BOARD_SIZE>& def, PCG64& rng) {
    vector<int> all = alive_indices(def);
    vector<int> taunts;
    for (int i: all) if (def[i] && (def[i]->keywords & TAUNT)) taunts.push_back(i);
    return taunts.empty() ? all : taunts;
}

static void enqueue_deaths(const array<optional<Minion>, BOARD_SIZE>& b, int side,
                           vector<DeathItem>& q) {
    for (int i=0;i<BOARD_SIZE;i++){
        if (b[i] && b[i]->health<=0) {
            q.push_back(DeathItem{side,i,*b[i]});
        }
    }
}

static bool summon_token(array<optional<Minion>, BOARD_SIZE>& b, const Minion& m, vector<string>& logs) {
    int e = first_empty(b);
    if (e==-1) { logs.push_back("BoardFull"); return false; }
    b[e] = m;
    return true;
}

static void trigger_deathrattle_and_reborn(array<optional<Minion>, BOARD_SIZE>& own,
                                          const Minion& dead,
                                          vector<string>& logs) {
    CardDef d = carddef(dead.card_id);
    for (auto &ss: d.deathrattle_summons) {
        Minion tok = make_minion(ss.card_id);
        tok.attack = ss.attack; tok.health = ss.health; tok.max_health = ss.health;
        tok.keywords = ss.keywords;
        (void)summon_token(own, tok, logs);
    }
    if (dead.keywords & REBORN) {
        Minion reb = dead;
        reb.health = 1;
        reb.keywords &= ~REBORN;
        (void)summon_token(own, reb, logs);
    }
}

static void process_death_queue(array<optional<Minion>, BOARD_SIZE>& A,
                                array<optional<Minion>, BOARD_SIZE>& B,
                                vector<DeathItem>& q,
                                vector<string>& logs) {
    while(!q.empty()) {
        DeathItem it = q.front();
        q.erase(q.begin());
        auto &own = (it.side==0?A:B);

        // Find minion: try slot first then instance id
        int slot = it.slot;
        if (!(0<=slot && slot<BOARD_SIZE && own[slot])) {
            bool found=false;
            if (!it.snap.instance_id.empty()){
                for (int i=0;i<BOARD_SIZE;i++){
                    if (own[i] && own[i]->instance_id==it.snap.instance_id) { slot=i; found=true; break; }
                }
            }
            if (!found) continue;
        }
        if (!own[slot]) continue;

        Minion dead = *own[slot];
        own[slot].reset(); // remove
        trigger_deathrattle_and_reborn(own, dead, logs);

        // Note: if your deathrattles can cause damage, you should enqueue_deaths() again here.
    }
}

struct CombatOutcome {
    int winner=-1; // -1 tie, 0 A, 1 B
    vector<string> logs;
};

static CombatOutcome run_combat(array<optional<Minion>, BOARD_SIZE> A,
                               array<optional<Minion>, BOARD_SIZE> B,
                               uint64_t seed_combat) {
    PCG64 rng(seed_combat, 54u);
    vector<string> logs;
    vector<DeathItem> deathQ;

    int aCnt=alive_count(A), bCnt=alive_count(B);
    int sideTurn = 0;
    if (aCnt>bCnt) sideTurn=0;
    else if (bCnt>aCnt) sideTurn=1;
    else sideTurn = rng.next_int(2);

    while (alive_count(A)>0 && alive_count(B)>0) {
        auto &atk = (sideTurn==0?A:B);
        auto &def = (sideTurn==0?B:A);

        int atkSlot = leftmost_alive(atk);
        if (atkSlot==-1) break;

        int swings = (atk[atkSlot] && (atk[atkSlot]->keywords & WINDFURY)) ? 2 : 1;

        for (int s=0;s<swings;s++){
            if (alive_count(A)==0 || alive_count(B)==0) break;
            if (!(atk[atkSlot] && atk[atkSlot]->health>0)) break;

            vector<int> cand = pick_targets(def, rng);
            if (cand.empty()) break;
            int tgtSlot = cand[rng.next_int((int)cand.size())];

            Minion &att = *atk[atkSlot];
            Minion &dfe = *def[tgtSlot];

            int dmgToDef = att.attack;
            int dmgToAtk = dfe.attack;

            apply_hit(dfe, dmgToDef);
            apply_hit(att, dmgToAtk);

            // Macaw: after it attacks, trigger leftmost friendly deathrattle (excluding itself)
            if (carddef(att.card_id).is_macaw) {
                int left=-1;
                for (int i=0;i<BOARD_SIZE;i++){
                    if (i==atkSlot) continue;
                    if (atk[i] && atk[i]->health>0) { left=i; break; }
                }
                if (left!=-1) {
                    CardDef d = carddef(atk[left]->card_id);
                    for (auto &ss: d.deathrattle_summons) {
                        Minion tok = make_minion(ss.card_id);
                        tok.attack=ss.attack; tok.health=ss.health; tok.max_health=ss.health; tok.keywords=ss.keywords;
                        (void)summon_token(atk, tok, logs);
                    }
                }
            }

            enqueue_deaths(A,0,deathQ);
            enqueue_deaths(B,1,deathQ);
            process_death_queue(A,B,deathQ,logs);

            if (!(atk[atkSlot] && atk[atkSlot]->health>0)) break;
        }

        sideTurn ^= 1;
    }

    CombatOutcome out;
    out.logs = std::move(logs);
    int a=alive_count(A), b=alive_count(B);
    if (a==0 && b==0) out.winner=-1;
    else if (b==0) out.winner=0;
    else if (a==0) out.winner=1;
    else out.winner=-1;
    return out;
}

// -------------------- Event-driven viewer --------------------
// The docs emphasize: show event log with step/time, skip events that reference missing entities, and offline mode reads mock JSON. 
static optional<Minion> parse_minion_obj(const Value& v) {
    if (!v.is_object()) return nullopt;
    Minion m;
    m.card_id = v.get("card_id").as_string();
    m.instance_id = v.get("instance_id").as_string();
    m.attack = (int)v.get("attack").as_i64(0);
    m.health = (int)v.get("health").as_i64(0);
    m.max_health = (int)v.get("max_health").as_i64(m.health);
    m.golden = v.get("golden").as_bool(false);
    m.keywords = parse_keywords(v.get("keywords"));
    if (m.card_id.empty()) return nullopt;
    if (m.max_health==0) m.max_health = m.health;
    return m;
}

static void ensure_player(GameState& st, const string& pid) {
    if (st.players.find(pid)!=st.players.end()) return;
    PlayerState p;
    p.player_id = pid;
    p.board.fill(nullopt);
    st.players.emplace(pid, std::move(p));
}

static bool resolve_ref_minion(GameState& st, const Value& ref, Minion** outMinion, string* err) {
    // ref: {player_id, slot, instance_id}
    string pid = ref.get("player_id").as_string();
    long long slotLL = ref.get("slot").as_i64(-1);
    string inst = ref.get("instance_id").as_string();
    if (pid.empty()) { if(err) *err="missing player_id"; return false; }
    ensure_player(st, pid);
    auto &p = st.players[pid];

    if (0 <= slotLL && slotLL < BOARD_SIZE) {
        auto &om = p.board[(int)slotLL];
        if (om) { *outMinion = &(*om); return true; }
    }
    if (!inst.empty()) {
        for (int i=0;i<BOARD_SIZE;i++){
            if (p.board[i] && p.board[i]->instance_id == inst) { *outMinion = &(*p.board[i]); return true; }
        }
    }
    if (err) {
        std::ostringstream ss;
        ss << "missing referenced minion (player_id="<<pid<<", slot="<<slotLL<<", instance_id="<<inst<<")";
        *err = ss.str();
    }
    return false;
}

static void apply_delta_state(GameState& st, const Value& payload) {
    // Tolerant patching for common keys: player_id, gold, tavern_tier, shop_frozen, board, hand, shop
    string pid = payload.get("player_id").as_string();
    if (pid.empty()) return;
    ensure_player(st,pid);
    auto &p = st.players[pid];

    if (!payload.get("gold").is_null()) p.gold = (int)payload.get("gold").as_i64(p.gold);
    if (!payload.get("health").is_null()) p.health = (int)payload.get("health").as_i64(p.health);
    if (!payload.get("tavern_tier").is_null()) p.tavern_tier = (int)payload.get("tavern_tier").as_i64(p.tavern_tier);
    if (!payload.get("shop_frozen").is_null()) p.shop_frozen = payload.get("shop_frozen").as_bool(p.shop_frozen);

    // board: array length 7 with objects or nulls
    const Value& b = payload.get("board");
    if (b.is_array()) {
        for (int i=0;i<BOARD_SIZE && i<(int)b.a.size();i++){
            if (b.a[i].is_null()) p.board[i].reset();
            else p.board[i] = parse_minion_obj(b.a[i]);
        }
    }
    // hand: array
    const Value& h = payload.get("hand");
    if (h.is_array()) {
        p.hand.clear();
        for (auto &x: h.a) {
            auto om = parse_minion_obj(x);
            if (om) p.hand.push_back(*om);
        }
        if ((int)p.hand.size() > HAND_SIZE) p.hand.resize(HAND_SIZE);
    }
    // shop: array
    const Value& s = payload.get("shop");
    if (s.is_array()) {
        p.shop.clear();
        for (auto &x: s.a) {
            if (x.is_null()) p.shop.push_back(nullopt);
            else p.shop.push_back(parse_minion_obj(x));
        }
    }
}

static void apply_event(GameState& st, const Value& ev, vector<string>& logPanel) {
    string type = ev.get("type").as_string();
    string uuid = ev.get("event_uuid").as_string();
    long long step = ev.get("step").as_i64(-1);
    const Value& payload = ev.get("payload");

    auto pushLog = [&](const string& msg){
        std::ostringstream ss;
        ss << "[step " << step << "] " << msg;
        logPanel.push_back(ss.str());
    };

    if (!payload.is_object()) {
        pushLog("Invalid event payload (not object); skipped");
        return;
    }

    string kind = payload.get("kind").as_string();
    string text = payload.get("log").as_string();

    // If event references missing entities -> log error and skip (as spec says) 
    // We'll only enforce for payload.source / payload.target if present.
    auto check_ref = [&](const Value& ref)->bool{
        if (!ref.is_object()) return true;
        Minion* mptr=nullptr;
        string err;
        if (!resolve_ref_minion(st, ref, &mptr, &err)) {
            pushLog("ERROR: " + err + " ; event skipped");
            return false;
        }
        return true;
    };

    if (payload.get("source").is_object() && !check_ref(payload.get("source"))) return;
    if (payload.get("target").is_object() && !check_ref(payload.get("target"))) return;

    if (kind=="delta_state") {
        apply_delta_state(st, payload);
        pushLog(text.empty() ? "delta_state applied" : text);
        return;
    }

    if (kind=="board_remove") {
        const Value& tgt = payload.get("target");
        string pid = tgt.get("player_id").as_string();
        int slot = (int)tgt.get("slot").as_i64(-1);
        ensure_player(st,pid);
        if (0<=slot && slot<BOARD_SIZE) st.players[pid].board[slot].reset();
        pushLog(text.empty()? "board_remove": text);
        return;
    }

    if (kind=="board_add") {
        // payload: {player_id, minion:{...}, slot?}
        string pid = payload.get("player_id").as_string();
        ensure_player(st,pid);
        auto om = parse_minion_obj(payload.get("minion"));
        int slot = (int)payload.get("slot").as_i64(-1);
        if (!om) { pushLog("board_add missing minion; skipped"); return; }
        auto &p = st.players[pid];
        if (!(0<=slot && slot<BOARD_SIZE) || p.board[slot]) slot = first_empty(p.board);
        if (slot!=-1) p.board[slot] = *om;
        else pushLog("BoardFull");
        pushLog(text.empty()? "board_add": text);
        return;
    }

    if (kind=="deathrattle_trigger") {
        // payload includes summons array; each summon has slot possibly null -> put in first empty
        const Value& summons = payload.get("summons");
        if (summons.is_array()) {
            for (auto &s : summons.a) {
                string pid = s.get("player_id").as_string();
                ensure_player(st,pid);
                Minion tok;
                tok.card_id = s.get("card_id").as_string();
                tok.attack = (int)s.get("attack").as_i64(0);
                tok.health = (int)s.get("health").as_i64(0);
                tok.max_health = tok.health;
                tok.keywords = parse_keywords(s.get("keywords"));
                int slot = (int)s.get("slot").as_i64(-1); // null -> -1
                auto &p = st.players[pid];
                if (!(0<=slot && slot<BOARD_SIZE) || p.board[slot]) slot = first_empty(p.board);
                if (slot==-1) pushLog("BoardFull");
                else p.board[slot] = tok;
            }
        }
        pushLog(text.empty()? "deathrattle_trigger": text);
        return;
    }

    if (kind=="update_leaderboard") {
        // payload: list or single; we accept array "entries" or direct fields.
        const Value& entries = payload.get("entries");
        if (entries.is_array()) {
            st.leaderboard.clear();
            for (auto &e : entries.a) {
                LeaderEntry le;
                le.player_id = e.get("player_id").as_string();
                le.health = (int)e.get("health").as_i64(40);
                le.tavern_tier = (int)e.get("level_tavern").as_i64(e.get("tavern_tier").as_i64(1));
                le.is_dead = e.get("is_dead").as_bool(false);
                st.leaderboard.push_back(le);
            }
        } else {
            LeaderEntry le;
            le.player_id = payload.get("player_id").as_string();
            le.health = (int)payload.get("health").as_i64(st.players[le.player_id].health);
            le.tavern_tier = (int)payload.get("level_tavern").as_i64(st.players[le.player_id].tavern_tier);
            le.is_dead = payload.get("is_dead").as_bool(false);
            st.leaderboard.push_back(le);
        }
        pushLog(text.empty()? "update_leaderboard": text);
        return;
    }

    // default: just log
    if (!text.empty()) pushLog(text);
    else pushLog(type + "/" + kind + " received");
}

static vector<Value> load_event_log(const string& path) {
    string s = read_file(path);
    Value root = minijson::parse(s);
    vector<Value> out;
    if (root.is_array()) {
        out = root.a;
    } else if (root.is_object()) {
        // might be {events:[...]} or a single event
        if (root.get("events").is_array()) out = root.get("events").a;
        else out.push_back(root);
    } else {
        throw runtime_error("Event log JSON must be array or object");
    }
    return out;
}

// -------------------- Simple playable round (CLI) --------------------
static vector<string> BASIC_POOL = {
    "BuzzingVermin","NestSwarmer","MonstrousMacaw",
    "WrathWeaver","FuriousDriver","Implicator","Felbat","ImpMama"
};

static void shop_refresh(PlayerState& p, PCG64& rng) {
    // If frozen, only refill empty slots (simplified interpretation).
    if (p.shop.empty()) p.shop.resize(3);
    for (size_t i=0;i<p.shop.size();i++){
        if (p.shop_frozen && p.shop[i].has_value()) continue;
        string cid = BASIC_POOL[rng.next_int((int)BASIC_POOL.size())];
        p.shop[i] = make_minion(cid, "shop-"+to_string(rng.next_u64()));
    }
}

static bool board_has_empty(const PlayerState& p) { return first_empty(p.board) != -1; }

static void end_of_turn_effects(PlayerState& p, PCG64& rng) {
    // Very simplified: Implicator consumes 1 shop minion at end of turn to gain stats (if any)
    for (int i=0;i<BOARD_SIZE;i++){
        if (!p.board[i]) continue;
        if (p.board[i]->card_id=="Implicator") {
            // find first non-empty shop minion
            for (size_t s=0;s<p.shop.size();s++){
                if (p.shop[s]) {
                    p.board[i]->attack += p.shop[s]->attack;
                    p.board[i]->health += p.shop[s]->health;
                    p.board[i]->max_health += p.shop[s]->health;
                    p.shop[s].reset();
                    break;
                }
            }
        }
    }
    (void)rng;
}

static void play_one_round() {
    GameState st;
    ensure_player(st, "p1");
    ensure_player(st, "p2");

    auto &me = st.players["p1"];
    auto &op = st.players["p2"];
    me.board.fill(nullopt); op.board.fill(nullopt);
    me.gold = 3; me.health=40; me.tavern_tier=1;
    op.gold = 3; op.health=40; op.tavern_tier=1;

    PCG64 rng(123456789ULL, 54u);

    // initial shop for both
    me.shop.resize(3); op.shop.resize(3);
    shop_refresh(me, rng);
    shop_refresh(op, rng);

    cout << "=== Recruit Phase (CLI demo) ===\n";
    cout << "Rules used here match doc basics: start 3 gold, buy=3, sell=1, refresh=1, freeze free.\n\n";
    bool running=true;
    while (running) {
        cout << "\n--- Your state ---\n";
        show_player(me);
        cout << "\nCommands:\n";
        cout << "  buy <shopSlot>\n";
        cout << "  play <handIndex> [boardSlot]\n";
        cout << "  sell <boardSlot>\n";
        cout << "  refresh\n";
        cout << "  freeze (toggle)\n";
        cout << "  end (go to combat)\n";
        cout << "> ";
        string cmd; 
        if(!(cin>>cmd)) break;

        if (cmd=="buy") {
            int s; cin>>s;
            if (me.gold < 3) { cout << "Not enough gold.\n"; continue; }
            if (!(0<=s && s<(int)me.shop.size()) || !me.shop[s]) { cout << "Invalid shop slot.\n"; continue; }
            if ((int)me.hand.size() >= HAND_SIZE) { cout << "HandFull.\n"; continue; }
            me.gold -= 3;
            me.hand.push_back(*me.shop[s]);
            me.shop[s].reset();
            cout << "Bought.\n";
        } else if (cmd=="play") {
            int h; cin>>h;
            int slot=-1;
            if (cin.peek()==' ') {
                // attempt read optional slot; if next token isn't numeric, ignore
                streampos pos = cin.tellg();
                string maybe; 
                if (cin>>maybe) {
                    bool ok = !maybe.empty() && (isdigit((unsigned char)maybe[0]) || maybe[0]=='-');
                    if (ok) slot = stoi(maybe);
                    else { cin.clear(); cin.seekg(pos); } // best-effort
                }
            }
            if (!(0<=h && h<(int)me.hand.size())) { cout << "Invalid hand index.\n"; continue; }
            if (!board_has_empty(me) && !(0<=slot && slot<BOARD_SIZE && !me.board[slot])) {
                cout << "BoardFull.\n"; continue;
            }
            if (!(0<=slot && slot<BOARD_SIZE) || me.board[slot]) slot = first_empty(me.board);
            Minion m = me.hand[h];
            me.hand.erase(me.hand.begin()+h);
            me.board[slot] = m;

            // Simplified synergy: if you play a demon, WrathWeaver on board gains +2/+2
            if (carddef(m.card_id).is_demon) {
                for (int i=0;i<BOARD_SIZE;i++){
                    if (me.board[i] && me.board[i]->card_id=="WrathWeaver") {
                        me.board[i]->attack += 2;
                        me.board[i]->health += 2;
                        me.board[i]->max_health += 2;
                    }
                }
            }

            cout << "Played to board slot " << slot << ".\n";
        } else if (cmd=="sell") {
            int b; cin>>b;
            if (!(0<=b && b<BOARD_SIZE) || !me.board[b]) { cout << "Invalid board slot.\n"; continue; }
            me.board[b].reset();
            me.gold += 1;
            if (me.gold > 10) me.gold = 10; // cap
            cout << "Sold.\n";
        } else if (cmd=="refresh") {
            if (me.gold < 1) { cout << "Not enough gold.\n"; continue; }
            me.gold -= 1;
            shop_refresh(me, rng);
            cout << "Refreshed.\n";
        } else if (cmd=="freeze") {
            me.shop_frozen = !me.shop_frozen;
            cout << "Frozen=" << (me.shop_frozen?"yes":"no") << "\n";
        } else if (cmd=="end") {
            running=false;
        } else {
            cout << "Unknown command.\n";
        }
    }

    // Opponent auto-buys/plays randomly (very simple AI)
    while (op.gold >= 3 && (int)op.hand.size() < HAND_SIZE) {
        int s = rng.next_int((int)op.shop.size());
        if (!op.shop[s]) break;
        op.gold -= 3;
        op.hand.push_back(*op.shop[s]);
        op.shop[s].reset();
        if (board_has_empty(op)) {
            int b = first_empty(op.board);
            op.board[b] = op.hand.back();
            op.hand.pop_back();
        }
    }

    end_of_turn_effects(me, rng);
    end_of_turn_effects(op, rng);

    cout << "\n=== Combat Phase ===\n";
    cout << "\nYour board:\n"; show_player(me);
    cout << "\nOpponent board:\n"; show_player(op);

    uint64_t seed_combat = 987654321ULL;
    auto out = run_combat(me.board, op.board, seed_combat);

    cout << "\nCombat winner: " << (out.winner==-1?"Tie":(out.winner==0?"You":"Opponent")) << "\n";
    if (!out.logs.empty()) {
        cout << "Engine logs (only BoardFull / macaw triggers in this demo):\n";
        for (auto &s: out.logs) cout << "  - " << s << "\n";
    }
}

// -------------------- Main --------------------
static void usage() {
    cout << "hb_client (C++17)\n";
    cout << "Usage:\n";
    cout << "  hb_client --play\n";
    cout << "  hb_client --viewer <path_to_mock_log.json>\n";
    cout << "\nViewer mode reads the mock payloads JSON and prints a log panel with step numbers.\n";
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    try {
        if (argc < 2) { usage(); return 0; }
        string mode = argv[1];

        if (mode=="--play") {
            play_one_round();
            return 0;
        }

        if (mode=="--viewer") {
            if (argc < 3) { usage(); return 1; }
            string path = argv[2];
            vector<Value> events = load_event_log(path);

            GameState st;
            vector<string> logPanel;

            cout << "=== Offline Viewer ===\n";
            cout << "Loaded events: " << events.size() << "\n";
            cout << "Press ENTER to consume up to 5 events per tick.\n\n";

            size_t idx = 0;
            string dummy;
            getline(cin, dummy); // consume pending newline

            while (idx < events.size()) {
                cout << "---- Tick (events " << idx << " .. " << min(idx+5, events.size())-1 << ") ----\n";
                size_t consumed = 0;
                while (consumed < 5 && idx < events.size()) {
                    apply_event(st, events[idx], logPanel);
                    idx++; consumed++;
                }

                // Render log panel (last 20 lines)
                cout << "\nLogPanel (last 20):\n";
                int start = (int)max<long long>(0, (long long)logPanel.size()-20);
                for (int i=start;i<(int)logPanel.size();i++) cout << "  " << logPanel[i] << "\n";

                // Render players if present
                cout << "\nKnown players: " << st.players.size() << "\n";
                for (auto &kv: st.players) {
                    cout << "\n";
                    show_player(kv.second);
                }
                show_leaderboard(st);

                cout << "\n(ENTER for next tick, or 'q' then ENTER to quit) ";
                getline(cin, dummy);
                if (!dummy.empty() && (dummy[0]=='q' || dummy[0]=='Q')) break;
                cout << "\n";
            }

            cout << "\nDone.\n";
            return 0;
        }

        usage();
        return 1;
    } catch (const exception& e) {
        cerr << "ERROR: " << e.what() << "\n";
        return 1;
    }
}
