
# hb_client (C++17)

A small **offline** CLI client inspired by the course docs: it can
1) **Play one simple round** (Recruit -> Combat) in terminal, and
2) **View mock payload logs** (event-driven viewer) and print a log panel.

## Build (Linux/macOS)

```bash
g++ -std=c++17 -O2 -Wall -Wextra -pedantic main.cpp -o hb_client
```

## Run

### 1) Play demo round
```bash
./hb_client --play
```

### 2) Offline viewer for mock logs
```bash
./hb_client --viewer data/mock_combat_log_advanced.json
```

The viewer expects a JSON file that is either:
- an array of events: `[ {...}, {...} ]`
- or an object with `events: [ ... ]`
- or a single event object.

The implementation is tolerant and will:
- show `[step N]` in the log panel
- skip events that reference missing entities (and print an ERROR line)

