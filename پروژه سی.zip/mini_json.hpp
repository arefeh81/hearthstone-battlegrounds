
#pragma once
#include <string>
#include <vector>
#include <map>
#include <stdexcept>
#include <cctype>
#include <sstream>

namespace minijson {

struct Value {
    enum class Type { Null, Bool, Number, String, Array, Object } type = Type::Null;
    bool b = false;
    double num = 0.0;
    std::string s;
    std::vector<Value> a;
    std::map<std::string, Value> o;

    Value() = default;
    static Value null() { return Value(); }
    static Value boolean(bool v){ Value x; x.type=Type::Bool; x.b=v; return x; }
    static Value number(double v){ Value x; x.type=Type::Number; x.num=v; return x; }
    static Value string(std::string v){ Value x; x.type=Type::String; x.s=std::move(v); return x; }
    static Value array(std::vector<Value> v){ Value x; x.type=Type::Array; x.a=std::move(v); return x; }
    static Value object(std::map<std::string,Value> v){ Value x; x.type=Type::Object; x.o=std::move(v); return x; }

    bool is_null()   const { return type==Type::Null; }
    bool is_bool()   const { return type==Type::Bool; }
    bool is_number() const { return type==Type::Number; }
    bool is_string() const { return type==Type::String; }
    bool is_array()  const { return type==Type::Array; }
    bool is_object() const { return type==Type::Object; }

    // Safe accessors (return default if mismatch / missing)
    const Value& get(const std::string& k) const {
        static Value nil;
        if (!is_object()) return nil;
        auto it = o.find(k);
        if (it==o.end()) return nil;
        return it->second;
    }
    Value& get(const std::string& k) {
        if (!is_object()) { type=Type::Object; o.clear(); }
        return o[k];
    }
    const Value& at(size_t i) const {
        static Value nil;
        if (!is_array() || i>=a.size()) return nil;
        return a[i];
    }
    size_t size() const {
        if (is_array()) return a.size();
        if (is_object()) return o.size();
        return 0;
    }

    std::string as_string(const std::string& def="") const {
        if (is_string()) return s;
        return def;
    }
    long long as_i64(long long def=0) const {
        if (is_number()) return (long long)num;
        if (is_bool()) return b?1:0;
        return def;
    }
    double as_f64(double def=0) const {
        if (is_number()) return num;
        if (is_bool()) return b?1.0:0.0;
        return def;
    }
    bool as_bool(bool def=false) const {
        if (is_bool()) return b;
        if (is_number()) return num!=0.0;
        return def;
    }
};

// -------- Parser --------
struct Parser {
    const std::string* src = nullptr;
    size_t i = 0;

    explicit Parser(const std::string& s): src(&s), i(0) {}

    char peek() const { return i < src->size() ? (*src)[i] : '\0'; }
    char getc() { return i < src->size() ? (*src)[i++] : '\0'; }

    void skip_ws() {
        while (std::isspace((unsigned char)peek())) i++;
    }

    [[noreturn]] void err(const std::string& msg) const {
        std::ostringstream oss;
        oss << "JSON parse error at pos " << i << ": " << msg;
        throw std::runtime_error(oss.str());
    }

    bool consume(char c) {
        skip_ws();
        if (peek()==c) { i++; return true; }
        return false;
    }

    void expect(char c) {
        skip_ws();
        if (peek()!=c) err(std::string("expected '") + c + "'");
        i++;
    }

    Value parse_value() {
        skip_ws();
        char c = peek();
        if (c=='\0') err("unexpected end");
        if (c=='n') return parse_null();
        if (c=='t' || c=='f') return parse_bool();
        if (c=='"' ) return parse_string();
        if (c=='[' ) return parse_array();
        if (c=='{' ) return parse_object();
        if (c=='-' || std::isdigit((unsigned char)c)) return parse_number();
        err(std::string("unexpected char '")+c+"'");
        return Value::null();
    }

    Value parse_null() {
        if (src->compare(i,4,"null")!=0) err("invalid null");
        i += 4;
        return Value::null();
    }

    Value parse_bool() {
        if (src->compare(i,4,"true")==0) { i+=4; return Value::boolean(true); }
        if (src->compare(i,5,"false")==0){ i+=5; return Value::boolean(false); }
        err("invalid bool");
        return Value::boolean(false);
    }

    Value parse_number() {
        skip_ws();
        size_t start = i;
        if (peek()=='-') i++;
        while (std::isdigit((unsigned char)peek())) i++;
        if (peek()=='.') {
            i++;
            while (std::isdigit((unsigned char)peek())) i++;
        }
        if (peek()=='e' || peek()=='E') {
            i++;
            if (peek()=='+' || peek()=='-') i++;
            while (std::isdigit((unsigned char)peek())) i++;
        }
        std::string token = src->substr(start, i-start);
        char* endp=nullptr;
        double v = std::strtod(token.c_str(), &endp);
        if (!endp || *endp!='\0') err("invalid number");
        return Value::number(v);
    }

    static int hexval(char c){
        if ('0'<=c && c<='9') return c-'0';
        if ('a'<=c && c<='f') return 10+(c-'a');
        if ('A'<=c && c<='F') return 10+(c-'A');
        return -1;
    }

    // Minimal UTF-16 \uXXXX handling for BMP only; for non-BMP we keep as '?'.
    Value parse_string() {
        expect('"');
        std::string out;
        while (true) {
            char c = getc();
            if (c=='\0') err("unterminated string");
            if (c=='"') break;
            if (c=='\\') {
                char e = getc();
                if (e=='"'||e=='\\'||e=='/') out.push_back(e);
                else if (e=='b') out.push_back('\b');
                else if (e=='f') out.push_back('\f');
                else if (e=='n') out.push_back('\n');
                else if (e=='r') out.push_back('\r');
                else if (e=='t') out.push_back('\t');
                else if (e=='u') {
                    int h1=hexval(getc()), h2=hexval(getc()), h3=hexval(getc()), h4=hexval(getc());
                    if (h1<0||h2<0||h3<0||h4<0) err("invalid unicode escape");
                    int code = (h1<<12)|(h2<<8)|(h3<<4)|h4;
                    if (code < 0x80) out.push_back((char)code);
                    else if (code < 0x800) {
                        out.push_back((char)(0xC0 | (code>>6)));
                        out.push_back((char)(0x80 | (code&0x3F)));
                    } else {
                        out.push_back((char)(0xE0 | (code>>12)));
                        out.push_back((char)(0x80 | ((code>>6)&0x3F)));
                        out.push_back((char)(0x80 | (code&0x3F)));
                    }
                } else err("invalid escape");
            } else {
                out.push_back(c);
            }
        }
        return Value::string(std::move(out));
    }

    Value parse_array() {
        expect('[');
        std::vector<Value> arr;
        skip_ws();
        if (consume(']')) return Value::array(std::move(arr));
        while (true) {
            arr.push_back(parse_value());
            skip_ws();
            if (consume(']')) break;
            expect(',');
        }
        return Value::array(std::move(arr));
    }

    Value parse_object() {
        expect('{');
        std::map<std::string, Value> obj;
        skip_ws();
        if (consume('}')) return Value::object(std::move(obj));
        while (true) {
            skip_ws();
            if (peek()!='"') err("object key must be string");
            std::string key = parse_string().s;
            skip_ws();
            expect(':');
            Value val = parse_value();
            obj.emplace(std::move(key), std::move(val));
            skip_ws();
            if (consume('}')) break;
            expect(',');
        }
        return Value::object(std::move(obj));
    }
};

inline Value parse(const std::string& s) {
    Parser p(s);
    Value v = p.parse_value();
    p.skip_ws();
    if (p.i != s.size()) throw std::runtime_error("JSON parse error: trailing characters");
    return v;
}

} // namespace minijson
